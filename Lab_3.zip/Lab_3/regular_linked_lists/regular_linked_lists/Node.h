#pragma once
#ifndef Node_h
#define Node_h

struct Node {
	int data;
	Node* next;
};

void append(Node* n, int d) {
	Node* temp = new Node();
	temp->data = d;
	temp->next = NULL;

	Node* curr = n;
	while (curr->next != NULL) {
		curr = curr->next;
	}
	curr -> next = temp;
}
#endif