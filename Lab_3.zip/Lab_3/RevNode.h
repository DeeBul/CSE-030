#ifndef RevNode_h
#define RevNode_h

// Define the Node struct below



// Define the append function below



// Do not write any code below this line
#endif
