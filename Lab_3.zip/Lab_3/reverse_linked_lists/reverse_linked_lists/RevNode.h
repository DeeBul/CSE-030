//#pragma once
#ifndef RevNode_h
#define RevNode_h

// Define the Node struct below
struct Node {
	int data;
	Node* next;
	Node* prev;
};


// Define the append function below
Node* append(Node* n, int d) {

	Node* node1 = new Node();
	Node* prev = new Node();
	node1->data = d;
	node1->next = NULL;
	node1->prev = NULL;

		Node* temp = n;

	while (temp->next != NULL) {
		temp = temp->next;
	}
	node1->prev = temp;
	temp->next = node1;


		return node1;
}


// Do not write any code below this line
#endif