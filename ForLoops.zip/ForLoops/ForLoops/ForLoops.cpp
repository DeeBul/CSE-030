// ForLoops.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include<iostream>

using namespace std;


int main()
{
	int x; 
	int i;
	cin >> x;
	
	for (i = 0; i < x; i++) {
		cout << "CSE30 is my favorite class!" << endl;
	}
	cout << x << endl;
    return 0;
}

