#ifndef Queue_h
#define Queue_h

// The Node data structure
struct Node {
	long data;
	Node* next;

	Node(long d) {
		data = d;
		next = NULL;
	}

	~Node() {

	}
};


struct Queue {
	// Implement the Queue data structure so that the code works
	Node* head;
	Node* tail;

	Queue() {
		head = NULL;
		tail = NULL;
	}

	bool isEmpty() {
		if (head == NULL) {
			return true;
		}
		else {
			return false;
		}
	}

	void push(long value) {
		if (isEmpty()) {
			Node* curr = new Node(value);
			head = curr;
			tail = head;
			//curr = tail->next;
		}
		else {
			Node* curr = new Node(value);
			tail->next = curr;
			tail = curr;
		}
	}

	long pop() {
		Node* temp; 
		temp = head->next;
		long val;
		val = head->data;

		delete head;

		head = temp;
		return val;
	}
	long print() {
		Node* temp;
		temp = head;
		while (temp != NULL) {
			temp = temp->next;
			return temp->data;
		}
	}
	long peek() {
		return head->data;
	}

	~Queue() {
		while (!isEmpty()) {
			pop();
		}
	}
};

#endif
