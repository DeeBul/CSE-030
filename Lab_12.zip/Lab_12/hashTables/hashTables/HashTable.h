#ifndef HashTable_h
#define HashTable_h

using namespace std;
// This is just the node that we have used for linked lists/stacks/queues
struct Node {
	long data;
	Node* next;


	Node(long data) {
		this->data = data;
		next = NULL;
	}
};


struct HashTable {
	// Data will be stored in an array of queues
	// So a pointer to a pointer of Node
	Node** array;

	// The size is how many elements we wish to store
	long size;

	// Constructor, allocates enough memory for the table
	// and initializes it to NULL
	HashTable(long size) {

		array = (Node**)malloc(sizeof(Node*) * size);

		for (long i = 0; i < size; i++) {
			array[i] = NULL;
		}
		this->size = size;
	}

	// A hashing function
	long hash(long value) {
		return value % size;
		// Provide code here...
		// It should be "fast"
	}

	// Insert function
	void insert(long value) {
		//Node* curr = array[hash(value)];

		if (array[hash(value)] == NULL) {
			Node* newN = new Node(value);
			array[hash(value)] = newN;
		}
		else {
			Node* newN = new Node(value);
			Node* temp = array[hash(value)];
			array[hash(value)] = newN;
			array[hash(value)]->next = temp;
		}
		// Provide code here
		// It should be O(1)
	}

	// A search function
	bool search(long value) {
		bool flag = false;
		//int spot = 0;
		while (array[hash(value)]->next != NULL) {
			if (array[hash(value)]->data == value) {
				flag = true;
			}
			array[hash(value)] = array[hash(value)]->next;
		}
		if (flag == true) {
			return true;
		}
		else {
			return false;
		}

		// Provide code here...
		// It should be amortized O(1)
		// Which means incredibly fast
	}

	// A function to display the contents of the table
	void print() {
		for (long i = 0; i < size; i++) {
			Node* curr = array[i];
			if (curr != NULL) {
				while (curr != NULL) {
					std::cout << curr->data << " ";
					curr = curr->next;
				}
				std::cout << std::endl;
			}
		}
	}

	// A function to delete a value from the table
	// It should delete the first occurrence of the value
	// Which means, you search for the value and delete it
	// If the value is not found in the table, you do nothing
	void remove(long value) {
		if (array[hash(value)] == NULL) {
			cout << "NULL" << endl;
		}
		else if (array[hash(value)]->data == value) {
			Node* temp = array[hash(value)];
			array[hash(value)] = array[hash(value)]->next;
			delete temp;
		}
		else {
			while (array[hash(value)]->next != NULL) {
				Node* temp = array[hash(value)];
				if (array[hash(value)]->data == value) {
						Node* prev = array[hash(value)]; 
						Node* tempt = prev->next;
						prev->next = tempt->next;
						delete tempt;
				}
			}


		}
		//Node* temp = array[hash(value)];


	}
	// Provide code here...
	// It should be amortized O(1)
	// Again, amortized f  but other times it will be cheap
	// With amortized analysis, we consider both cases
	// and amortized O(1) means that the number of times
	// the operation will be expensive, is limited to a
	// very small value, and most of the time it will be O(1)
	//}

	// A destructor, which just releases the memory taken by the table
	~HashTable() {
		free(array);
	}

};

#endif /* HashTable_h */