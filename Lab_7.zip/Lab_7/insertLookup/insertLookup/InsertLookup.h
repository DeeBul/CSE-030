#pragma once
#ifndef InsertLookup_h
#define InsertLookup_h

/*bool find(long* list, long size, long value) {
	for (long i = 0; i < size; i++) {
		if (list[i] == value) {
			return true;
		}
	}

	return false;
}*/

bool find(long* list, long size, long val) {
	long n = size;
	long lower = 0;
	long upper = n;

	while (lower < upper) {
		long mid = lower + (upper - lower) / 2;
		if (list[mid] == val) {
			return true;
		}
		else if (list[mid] < val) {
			lower = mid + 1;
		}
		else {
			upper = mid;
		}
	}
	return false;
}

void insertion_sort(long list[], long size) {
	long n = size;
	for (long i = 0; i < n; i++) {
		long j = i;
		while (j > 0 && list[j - 1] > list[j]) {
			long temp = list[j];
			list[j] = list[j - 1];
			list[j - 1] = temp;
			j = j - 1;
		} 
	}
}

/*void quickSort(long* list, long start, long end) {
	long i = start;
	long j = end;
	long temp;

	long pivot = list[(start + end) / 2];

	while (i <= j) {
		while (list[i] < pivot) {
			i++;
		}
		while (list[j] > pivot) {
			j--;
		}
		if (i <= j) {
			temp = list[i];
			list[i] = list[j];
			list[j] = temp;
			i++;
			j--;
		}
	}
	if (start < j) {
		quickSort(list, start, j);
	}
	if (i < end) {
		quickSort(list, i, end);
	}
}*/



/*void merge(long* list, long start, long mid, long end) {
	long i = start;
	long j = mid + 1;

	while (j <= end && i <= mid) {
		if (list[i] < list[j]) {
			i++;
		}
		else {
			long temp = list[j];
			for (long k = j; k > i; k--) {
				list[k] = list[k - 1];
			}
			list[i] = temp;

			mid++;
			i++;
			j++;
		}
	}
}

void mergeSort(long* list, long start, long end) {
	if (start < end) {
		long mid = (start + end) / 2;

		mergeSort(list, start, mid);
		mergeSort(list, mid + 1, end);

		merge(list, start, mid, end);
}
}*/


void insert(long* list, long size, long value) {

	/*long j = size - 1;

	while (j > 0 && list[j] > value) {
		list[j] = list[j - 1];
		j = j - 1;
	}
	list[j + 1] = value;*/


	//[size - 1] = value;

	long curr = size - 1;
	
	while (curr > 0 && list[curr - 1] > list[curr]) {
		long temp = list[curr - 1];
		list[curr] = list[curr - 1];
		list[curr - 1] = temp;
		curr = curr - 1;
	}
	//list[size - 1] = value;
	insertion_sort(list, size);
}

#endif
