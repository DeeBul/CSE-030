
#pragma once
#ifndef FindMin_h
#define FindMin_h

// Declare and define the findMin function here
	 int findMin(int numbers[], int start, int end) {
		 
		 
		 int min = start;
		 
		 for (int i = start; i < end; i++) {
			 if (numbers[i] < min)
				 min = i;
			 }
		 
		 return min;
		 }

		

// Do not write any code below this line
#endif